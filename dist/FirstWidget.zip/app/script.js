/*
 * Subscribe to the EmbeddedApp onPageLoad event before initializing 
 */
 
ZOHO.embeddedApp.on("PageLoad").then(()=>{

    alert("Script is working");
	//Custom Bussiness logic goes here
});

/*
 * initializing the widget.
 */
ZOHO.embeddedApp.init();